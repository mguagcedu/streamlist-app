import React, { useEffect, useState } from "react";
import { useApp } from "../state/AppContext.jsx";

const TMDB_TOKEN =
  import.meta.env.VITE_TMDB_TOKEN ||
  (typeof window !== "undefined" ? window.__TMDB_TOKEN__ : "");

async function tmdb(path, q = "") {
  if (!TMDB_TOKEN) throw new Error("Missing TMDB token (.env VITE_TMDB_TOKEN).");
  const url = `https://api.themoviedb.org/3${path}${q}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${TMDB_TOKEN}` } });
  if (!res.ok) throw new Error(`TMDB ${res.status}: ${await res.text()}`);
  return res.json();
}

export default function StreamList(){
  const { myList, addToList, removeFromList, favorites, toggleFavorite } = useApp();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    tmdb("/trending/movie/week", "?language=en-US")
      .then(d => setResults(d.results || []))
      .catch(e => setErr(e.message));
  }, []);

  async function onSearch(e){
    e.preventDefault();
    setErr("");
    try{
      const d = await tmdb("/search/movie", `?query=${encodeURIComponent(query)}&language=en-US`);
      setResults(d.results || []);
    }catch(ex){ setErr(ex.message); }
  }

  const inList = (id) => myList.some(m => m.id === id);
  const isFav = (id) => favorites.some(m => m.id === id);

  return (
    <section className="grid-1row">
      <h1 style={{ margin: "8px 0" }}>StreamList</h1>

      {err && (
        <div
          style={{
            color: "#b91c1c",
            background: "#fee2e2",
            border: "1px solid #fecaca",
            padding: "10px",
            borderRadius: "10px"
          }}
        >
          {err}
        </div>
      )}

      <form className="row" onSubmit={onSearch}>
        <input
          type="text"
          placeholder="Search for a movie…"
          value={query}
          onChange={(e)=>setQuery(e.target.value)}
        />
        <button className="btn primary" type="submit">Search</button>
      </form>

      <div className="card-row">
        {results.map(m => (
          <article className="card" key={m.id} title={m.title}>
            <img
              src={
                m.poster_path
                  ? `https://image.tmdb.org/t/p/w342${m.poster_path}`
                  : "https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?q=80&w=600&auto=format&fit=crop"
              }
              alt={m.title}
              loading="lazy"
            />
            <div className="p">
              <div className="hstack">
                <strong className="kicker">{m.title}</strong>
                {isFav(m.id) && <span className="badge">Favorited</span>}
                {inList(m.id) && <span className="list-pill">In My List</span>}
              </div>
              <p className="dim small">
                {(m.release_date || "").slice(0,4)} • ⭐ {m.vote_average?.toFixed?.(1) ?? "–"}
              </p>
              <div className="row">
                {!inList(m.id)
                  ? <button className="btn" onClick={()=>addToList(m)}>Add to My List</button>
                  : <button className="btn" onClick={()=>removeFromList(m.id)}>Remove</button>}
                <button className="btn" onClick={()=>toggleFavorite(m)}>
                  {isFav(m.id) ? "Unfavorite" : "Favorite"}
                </button>
              </div>
            </div>
          </article>
        ))}
        {results.length === 0 && <div className="dim">No movies found.</div>}
      </div>

      <h3 style={{ margin: "12px 0 4px" }}>My List</h3>
      <div className="card-row">
        {myList.length === 0 && <div className="dim">Nothing saved yet.</div>}
        {myList.map(m => (
          <article className="card" key={m.id}>
            <img
              src={
                m.poster_path
                  ? `https://image.tmdb.org/t/p/w342${m.poster_path}`
                  : "https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?q=80&w=600&auto=format&fit=crop"
              }
              alt={m.title}
              loading="lazy"
            />
            <div className="p">
              <div className="hstack">
                <strong className="kicker">{m.title}</strong>
                {favorites.some(f=>f.id===m.id) && <span className="badge">Favorited</span>}
              </div>
              <div className="row">
                <a className="btn" href={`https://www.themoviedb.org/movie/${m.id}`} target="_blank" rel="noreferrer">TMDB</a>
                <button className="btn" onClick={()=>removeFromList(m.id)}>Delete</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
